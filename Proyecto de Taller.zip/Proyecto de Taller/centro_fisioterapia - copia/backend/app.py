import os
from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
import mysql.connector

FRONTEND_DIR = "/frontend"

app = Flask(__name__)
CORS(app)

def get_db_connection():
    return mysql.connector.connect(
        host=os.getenv("DB_HOST", "localhost"),
        port=int(os.getenv("DB_PORT", "3306")),
        user=os.getenv("DB_USER", "root"),
        password=os.getenv("DB_PASSWORD", ""),
        database=os.getenv("DB_NAME", "fisioterapia"),
    )

# Servir el frontend desde el mismo backend para evitar problemas al abrir
# archivos HTML directamente (file://) y simplificar CORS.
@app.route("/")
def index():
    return send_from_directory(FRONTEND_DIR, "index.html")

@app.route("/<path:path>")
def frontend(path):
    return send_from_directory(FRONTEND_DIR, path)

@app.after_request
def add_cors_headers(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type,Authorization"
    response.headers["Access-Control-Allow-Methods"] = "GET,PUT,POST,DELETE,OPTIONS"
    return response

@app.route("/api/pacientes", methods=["GET", "OPTIONS"])
def get_pacientes():
    if request.method == "OPTIONS":
        return jsonify({}), 200
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM pacientes ORDER BY id")
        return jsonify(cursor.fetchall())
    except Exception as e:
        print("--- ERROR EN GET PACIENTES ---", str(e))
        return jsonify({"error": str(e)}), 500
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

@app.route("/api/pacientes", methods=["POST", "OPTIONS"])
def add_paciente():
    if request.method == "OPTIONS":
        return jsonify({}), 200
    conn = None
    cursor = None
    try:
        data = request.get_json(silent=True) or {}
        nombre = data.get("nombre")
        apellido = data.get("apellido")
        telefono = data.get("telefono")
        obra_social = data.get("obra_social") or "Particular"

        if not nombre or not apellido or not telefono:
            return jsonify({"error": "Faltan datos obligatorios"}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            """INSERT INTO pacientes (nombre, apellido, telefono, obra_social)
               VALUES (%s, %s, %s, %s)""",
            (nombre, apellido, telefono, obra_social),
        )
        conn.commit()
        return jsonify({
            "id": cursor.lastrowid,
            "mensaje": "Paciente registrado con éxito"
        }), 201
    except Exception as e:
        if conn:
            conn.rollback()
        print("--- ERROR EN POST PACIENTE ---", str(e))
        return jsonify({"error": str(e)}), 500
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

@app.route("/api/turnos", methods=["GET", "OPTIONS"])
def get_turnos():
    if request.method == "OPTIONS":
        return jsonify({}), 200
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT t.id, t.fecha_hora, t.estado, t.motivo_consulta,
                   p.id AS paciente_id, p.nombre, p.apellido,
                   p.telefono, p.obra_social
            FROM turnos t
            JOIN pacientes p ON t.paciente_id = p.id
            ORDER BY t.fecha_hora
        """)
        return jsonify(cursor.fetchall())
    except Exception as e:
        print("--- ERROR EN GET TURNOS ---", str(e))
        return jsonify({"error": str(e)}), 500
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

@app.route("/api/turnos", methods=["POST", "OPTIONS"])
def add_turno():
    if request.method == "OPTIONS":
        return jsonify({}), 200
    conn = None
    cursor = None
    try:
        data = request.get_json(silent=True) or {}
        paciente_id = data.get("paciente_id")
        fecha_hora = data.get("fecha_hora")
        estado = data.get("estado") or "pendiente"
        motivo = data.get("motivo_consulta") or ""

        if not paciente_id or not fecha_hora:
            return jsonify({"error": "Paciente y fecha/hora son obligatorios"}), 400

        if estado not in ("pendiente", "cancelado", "finalizado"):
            return jsonify({"error": "Estado no válido"}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            """INSERT INTO turnos
               (paciente_id, fecha_hora, estado, motivo_consulta)
               VALUES (%s, %s, %s, %s)""",
            (paciente_id, fecha_hora, estado, motivo),
        )
        conn.commit()
        return jsonify({
            "id": cursor.lastrowid,
            "mensaje": "Turno registrado con éxito"
        }), 201
    except Exception as e:
        if conn:
            conn.rollback()
        print("--- ERROR EN POST TURNO ---", str(e))
        return jsonify({"error": str(e)}), 500
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

@app.route("/api/turnos/<int:id>/estado", methods=["PUT", "OPTIONS"])
def update_turno_estado(id):
    if request.method == "OPTIONS":
        return jsonify({}), 200
    conn = None
    cursor = None
    try:
        data = request.get_json(silent=True) or {}
        nuevo_estado = data.get("estado")

        if nuevo_estado not in ("pendiente", "cancelado", "finalizado"):
            return jsonify({"error": "Estado no válido"}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE turnos SET estado = %s WHERE id = %s",
            (nuevo_estado, id),
        )
        conn.commit()
        return jsonify({"mensaje": "Estado del turno actualizado correctamente"})
    except Exception as e:
        if conn:
            conn.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
