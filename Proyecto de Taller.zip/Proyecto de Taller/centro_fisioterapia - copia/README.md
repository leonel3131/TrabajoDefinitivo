# Centro de Fisioterapia

Sistema web de gestión para Práctica Profesional II.

## Stack
- Frontend: HTML, CSS, JavaScript
- Backend: Python + Flask
- Base de datos: MySQL 8
- Entorno: Docker Compose

## Ejecutar con Docker

Desde la carpeta del proyecto:

```bash
docker compose down -v
docker compose up -d --build
```

> `down -v` elimina el volumen anterior de MySQL. Es importante la primera vez que uses esta versión corregida, porque el proyecto original tenía una base de datos/esquema diferente.

Luego abrir:

**http://localhost:5000**

MySQL queda disponible en:
- Host: localhost
- Puerto: 3307
- Base de datos: fisioterapia
- Usuario: fisioterapia
- Contraseña: fisioterapia

## Qué se corrigió

- El backend ya usa las variables `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER` y `DB_PASSWORD` definidas en Docker Compose.
- Se unificó la base de datos en `fisioterapia`.
- Se corrigió el `schema.sql`, que antes creaba `centro_fisioterapia` mientras Docker configuraba `fisioterapia`.
- El backend ahora escucha en `0.0.0.0`, por lo que es accesible desde el contenedor.
- Flask ahora sirve el frontend, así no hace falta abrir los HTML directamente con `file://`.
- JavaScript usa `/api`, evitando problemas con `localhost`/`127.0.0.1`.
- Se agregaron cierres/rollback de conexiones para manejar mejor los errores.
