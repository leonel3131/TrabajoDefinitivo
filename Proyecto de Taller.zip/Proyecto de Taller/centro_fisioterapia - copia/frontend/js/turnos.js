const API_URL = '/api';
let listaPacientesGlobal = [];

document.addEventListener('DOMContentLoaded', () => {
    cargarSelectPacientes();
    cargarTurnos();

    const formTurno = document.getElementById('form-turno');
    if (formTurno) {
        formTurno.addEventListener('submit', registrarTurno);
    }
});

async function cargarSelectPacientes() {
    try {
        const respuesta = await fetch(`${API_URL}/pacientes`);
        listaPacientesGlobal = await respuesta.json();
        
        const select = document.getElementById('paciente_id');
        select.innerHTML = '<option value="">-- Seleccione un paciente registrado --</option>';
        
        listaPacientesGlobal.forEach(p => {
            const option = document.createElement('option');
            option.value = p.id;
            option.textContent = `${p.nombre} ${p.apellido} (Tel: ${p.telefono})`;
            select.appendChild(option);
        });
    } catch (error) {
        console.error('Error al cargar selector de pacientes:', error);
    }
}

function mostrarObraSocialSeleccionada() {
    const selectId = document.getElementById('paciente_id').value;
    const divObra = document.getElementById('ver-obra-social');
    
    if (!selectId) {
        divObra.textContent = '';
        return;
    }

    const pacienteEncontrado = listaPacientesGlobal.find(p => p.id == selectId);
    if (pacienteEncontrado) {
        const os = pacienteEncontrado.obra_social || 'Particular';
        divObra.textContent = `📋 Obra Social registrada: ${os}`;
    }
}

async function cargarTurnos() {
    try {
        const respuesta = await fetch(`${API_URL}/turnos`);
        const turnos = await respuesta.json();
        
        const tbody = document.querySelector('#tabla-turnos tbody');
        if (!tbody) return;
        
        tbody.innerHTML = '';
        turnos.forEach(t => {
            const fechaLegible = new Date(t.fecha_hora).toLocaleString();
            const osPaciente = t.obra_social || 'Particular';
            
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${t.nombre} ${t.apellido}</td>
                <td>${t.telefono}</td>
                <td><strong>${osPaciente}</strong></td>
                <td>${fechaLegible}</td>
                <td>${t.motivo_consulta || '-'}</td>
                <td><span class="badge ${t.estado}">${t.estado}</span></td>
            `;
            tbody.appendChild(tr);
        });
    } catch (error) {
        console.error('Error al cargar turnos:', error);
    }
}

async function registrarTurno(e) {
    e.preventDefault();
    
    const paciente_id = document.getElementById('paciente_id').value;
    const fecha_hora = document.getElementById('fecha_hora').value;
    const estado = document.getElementById('estado').value;
    const motivo_consulta = document.getElementById('motivo_consulta').value;

    try {
        const respuesta = await fetch(`${API_URL}/turnos`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ paciente_id, fecha_hora, estado, motivo_consulta })
        });

        if (respuesta.ok) {
            alert('¡Turno agendado con éxito!');
            document.getElementById('form-turno').reset();
            document.getElementById('ver-obra-social').textContent = '';
            cargarTurnos();
        } else {
            alert('Error al agendar el turno.');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('No se pudo conectar con el servidor.');
    }
}