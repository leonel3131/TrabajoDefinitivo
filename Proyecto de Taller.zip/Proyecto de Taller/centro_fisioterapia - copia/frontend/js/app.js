const API_URL = '/api';

document.addEventListener('DOMContentLoaded', () => {
    const formPaciente = document.getElementById('form-paciente');
    if (formPaciente) {
        cargarPacientes();
        formPaciente.addEventListener('submit', registrarPaciente);
    }
});

async function cargarPacientes() {
    try {
        const respuesta = await fetch(`${API_URL}/pacientes`);
        const pacientes = await respuesta.json();
        
        const tbody = document.querySelector('#tabla-pacientes tbody');
        if (!tbody) return;
        
        tbody.innerHTML = '';
        pacientes.forEach(p => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${p.id}</td>
                <td>${p.nombre}</td>
                <td>${p.apellido}</td>
                <td>${p.telefono}</td>
                <td><strong>${p.obra_social || 'Particular'}</strong></td>
            `;
            tbody.appendChild(tr);
        });
    } catch (error) {
        console.error('Error al cargar pacientes:', error);
    }
}

async function registrarPaciente(e) {
    e.preventDefault();
    
    const nombre = document.getElementById('nombre').value;
    const apellido = document.getElementById('apellido').value;
    const telefono = document.getElementById('telefono').value;
    const obra_social = document.getElementById('obra_social').value;

    try {
        const respuesta = await fetch(`${API_URL}/pacientes`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ nombre, apellido, telefono, obra_social })
        });

        if (respuesta.ok) {
            alert('¡Paciente registrado con éxito!');
            document.getElementById('form-paciente').reset();
            cargarPacientes();
        } else {
            alert('Error al registrar el paciente.');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('No se pudo conectar con el servidor.');
    }
}